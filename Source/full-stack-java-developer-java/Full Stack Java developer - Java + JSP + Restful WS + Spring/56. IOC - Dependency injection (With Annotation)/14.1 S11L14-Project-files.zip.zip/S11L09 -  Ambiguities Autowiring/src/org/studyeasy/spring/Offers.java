package org.studyeasy.spring;

public interface Offers {
  String getOffer();
}
