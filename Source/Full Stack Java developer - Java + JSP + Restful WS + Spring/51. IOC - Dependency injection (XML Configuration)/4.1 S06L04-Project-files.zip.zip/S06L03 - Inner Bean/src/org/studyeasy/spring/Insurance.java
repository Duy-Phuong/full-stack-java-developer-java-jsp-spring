package org.studyeasy.spring;

public interface Insurance {
    String showStatus();
    Offers getCurrentOffer();
}
