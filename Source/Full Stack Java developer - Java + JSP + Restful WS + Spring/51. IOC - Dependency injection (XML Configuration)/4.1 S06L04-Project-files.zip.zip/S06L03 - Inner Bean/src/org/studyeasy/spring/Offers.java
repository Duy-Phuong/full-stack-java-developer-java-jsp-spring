package org.studyeasy.spring;

public class Offers {
	public String getOffer(){
		return "Get 10% off on your next purchase";
	}
}
