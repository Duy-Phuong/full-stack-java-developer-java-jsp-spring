package org.studyeasy.spring;

public class Offers {
	private String offer = new String("Get 10% off on next purchase");

	public String getOffer() {
		return offer;
	}

	public void setOffer(String offer) {
		this.offer = offer;
	}

}
