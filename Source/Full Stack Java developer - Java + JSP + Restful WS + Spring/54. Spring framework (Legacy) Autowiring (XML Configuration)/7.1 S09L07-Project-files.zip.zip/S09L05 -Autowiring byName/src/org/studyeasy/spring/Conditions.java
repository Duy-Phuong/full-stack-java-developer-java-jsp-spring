package org.studyeasy.spring;

public class Conditions {
	String condition = "Insurance must be one year old";

	public String getCondition() {
		return condition;
	}

	public void setCondition(String condition) {
		this.condition = condition;
	}

	
	

}
