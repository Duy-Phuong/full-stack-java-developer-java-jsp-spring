package org.studyeasy.spring;

public class Offers {
	private String currentOffer = new String("Get 10% off on next purchase");

	public String getCurrentOffer() {
		return currentOffer;
	}

	public void setCurrentOffer(String currentOffer) {
		this.currentOffer = currentOffer;
	}
	
	


}
