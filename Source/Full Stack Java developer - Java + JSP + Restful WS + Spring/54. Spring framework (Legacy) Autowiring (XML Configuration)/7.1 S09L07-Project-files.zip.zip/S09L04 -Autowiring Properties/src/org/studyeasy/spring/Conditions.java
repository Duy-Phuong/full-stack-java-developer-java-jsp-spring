package org.studyeasy.spring;

public class Conditions {
	String currentCondition = "Insurance must be one year old";

	public String getCurrentCondition() {
		return currentCondition;
	}

	public void setCurrentCondition(String currentCondition) {
		this.currentCondition = currentCondition;
	}

	

}
