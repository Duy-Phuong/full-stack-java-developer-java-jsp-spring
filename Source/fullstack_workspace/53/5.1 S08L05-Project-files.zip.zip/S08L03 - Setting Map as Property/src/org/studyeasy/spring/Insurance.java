package org.studyeasy.spring;

import java.util.Map;

public interface Insurance {
    String showStatus();
    Map<String,String> getMembers();
}
