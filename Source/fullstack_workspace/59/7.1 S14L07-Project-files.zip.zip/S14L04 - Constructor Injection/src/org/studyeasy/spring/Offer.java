package org.studyeasy.spring;

public class Offer {
   public String currentOffer = "No Offers";

public String getCurrentOffer() {
	return currentOffer;
}

public void setCurrentOffer(String currentOffer) {
	this.currentOffer = currentOffer;
}
}
